from __future__ import annotations

import gzip
import io
import lzma
import pathlib
import plistlib
import struct
import sys
import tarfile


CPU_TYPE_ARM64 = 0x0100000C
MH_MAGIC_64 = 0xFEEDFACF
MH_CIGAM_64 = 0xCFFAEDFE
FAT_MAGIC = 0xCAFEBABE
FAT_MAGIC_64 = 0xCAFEBABF
PACKAGE_VERSION = "0.5.8~adts3diag10"
DIAGNOSTIC_MARKER = b"diag10_active_aacp_fd_reuse"


def read_ar(path: pathlib.Path) -> dict[str, bytes]:
    raw = path.read_bytes()
    if not raw.startswith(b"!<arch>\n"):
        raise ValueError("not a Debian ar archive")
    members: dict[str, bytes] = {}
    offset = 8
    while offset < len(raw):
        if offset + 60 > len(raw):
            raise ValueError("truncated ar member header")
        name = raw[offset : offset + 16].decode("ascii").strip().rstrip("/")
        size = int(raw[offset + 48 : offset + 58].decode("ascii").strip())
        start = offset + 60
        members[name] = raw[start : start + size]
        offset = start + size + (size & 1)
    return members


def read_payload(members: dict[str, bytes]) -> tuple[str, tarfile.TarFile]:
    payload_name = next(
        name for name in members if name.startswith("data.tar")
    )
    data = members[payload_name]
    if payload_name.endswith(".gz"):
        data = gzip.decompress(data)
    elif payload_name.endswith(".xz"):
        data = lzma.decompress(data)
    elif payload_name.endswith(".lzma"):
        data = lzma.decompress(data)
    return payload_name, tarfile.open(fileobj=io.BytesIO(data))


def normalize_payload_name(name: str) -> str:
    normalized = name.lstrip("./")
    if normalized.startswith("var/jb/"):
        normalized = normalized[len("var/jb/") :]
    return normalized


def read_control_archive(
    members: dict[str, bytes],
) -> tuple[str, tarfile.TarFile]:
    control_name = next(
        name for name in members if name.startswith("control.tar")
    )
    data = members[control_name]
    if control_name.endswith(".gz"):
        data = gzip.decompress(data)
    elif control_name.endswith(".xz"):
        data = lzma.decompress(data)
    elif control_name.endswith(".lzma"):
        data = lzma.decompress(data)
    return control_name, tarfile.open(fileobj=io.BytesIO(data))


def read_control(members: dict[str, bytes]) -> dict[str, str]:
    _, archive = read_control_archive(members)
    values: dict[str, str] = {}
    with archive:
        member_name = next(
            item.name
            for item in archive.getmembers()
            if item.name.lstrip("./") == "control"
        )
        extracted = archive.extractfile(member_name)
        if extracted is None:
            raise ValueError("control member is empty")
        for line in extracted.read().decode("utf-8").splitlines():
            if ": " in line:
                key, value = line.split(": ", 1)
                values[key] = value
    return values


def read_control_scripts(
    members: dict[str, bytes],
) -> dict[str, tarfile.TarInfo]:
    _, archive = read_control_archive(members)
    scripts: dict[str, tarfile.TarInfo] = {}
    with archive:
        for item in archive.getmembers():
            name = item.name.lstrip("./")
            if item.isfile() and name in ("postinst", "postrm"):
                scripts[name] = item
    return scripts


def macho_architectures(data: bytes) -> set[tuple[int, int]]:
    if len(data) < 8:
        return set()
    magic, count = struct.unpack_from(">II", data, 0)
    if magic in (FAT_MAGIC, FAT_MAGIC_64):
        result: set[tuple[int, int]] = set()
        cursor = 8
        for _ in range(count):
            if magic == FAT_MAGIC:
                cpu_type, cpu_subtype, _offset, _size, _align = (
                    struct.unpack_from(">iiIII", data, cursor)
                )
                cursor += 20
            else:
                (
                    cpu_type,
                    cpu_subtype,
                    _offset,
                    _size,
                    _align,
                    _reserved,
                ) = struct.unpack_from(">iiIIII", data, cursor)
                cursor += 32
            result.add(
                (
                    cpu_type & 0xFFFFFFFF,
                    cpu_subtype & 0x00FFFFFF,
                )
            )
        return result

    if len(data) < 12:
        return set()
    little_magic, cpu_type, cpu_subtype = struct.unpack_from("<Iii", data, 0)
    if little_magic == MH_MAGIC_64:
        return {(cpu_type & 0xFFFFFFFF, cpu_subtype & 0x00FFFFFF)}
    return set()


def main() -> int:
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} <package.deb>", file=sys.stderr)
        return 2
    package = pathlib.Path(sys.argv[1]).resolve()
    members = read_ar(package)
    control = read_control(members)
    if control.get("Package") != "com.lns.pogr.aacpdiag":
        raise ValueError(f"unexpected Package: {control.get('Package')!r}")
    if control.get("Version") != PACKAGE_VERSION:
        raise ValueError(f"unexpected Version: {control.get('Version')!r}")

    expected_scripts = {
        "postinst": (
            PACKAGE_VERSION.encode("ascii"),
            b"source_ready_file",
            b"claim-*",
            b"daemon_direct_fallback_begin",
            b"daemon_direct_fallback_status",
            b"/var/jb/Library/LaunchDaemons/com.lns.pogr.aacpdiagd.plist",
            b"/Library/LaunchDaemons/com.lns.pogr.aacpdiagd.plist",
            b"/var/jb/usr/bin/aacpdiagd",
            b"/usr/bin/aacpdiagd",
            b"plutil",
            b"PlistBuddy",
            b"ProgramArguments",
            b"daemon_plist_rewrite_begin",
            b"bootout",
            b"bootstrap",
            b"kickstart",
            b"${DPKG_ADMINDIR:-/var/lib/dpkg}/info/com.lns.pogr.aacpdiag.list",
        ),
        "postrm": (
            b"claim-*",
            b"result-bluetoothd.plist",
            b"result-aacpdiagd.plist",
            b"bootout",
            b"killall",
        ),
    }
    scripts = read_control_scripts(members)
    missing_scripts = sorted(set(expected_scripts) - set(scripts))
    if missing_scripts:
        raise ValueError(f"missing control scripts: {missing_scripts}")
    control_archive_name, control_archive = read_control_archive(members)
    with control_archive:
        for script_name, markers in expected_scripts.items():
            script_info = scripts[script_name]
            if script_info.mode & 0o111 == 0:
                raise ValueError(f"{script_name} is not executable")
            extracted = control_archive.extractfile(script_info)
            if extracted is None:
                raise ValueError(f"cannot read control script {script_name}")
            data = extracted.read()
            if b"\r" in data:
                raise ValueError(f"{script_name} contains CR characters")
            if not data.startswith(b"#!/bin/sh\n"):
                raise ValueError(
                    f"{script_name} does not start with a POSIX shell shebang"
                )
            missing_markers = [marker for marker in markers if marker not in data]
            if missing_markers:
                raise ValueError(
                    f"{script_name} is missing markers: {missing_markers}"
                )
            if b"heard" in data.lower():
                raise ValueError(
                    f"{script_name} still contains legacy heard handling"
                )

    payload_name, archive = read_payload(members)
    files: dict[str, tarfile.TarInfo] = {}
    for member in archive.getmembers():
        if not member.isfile():
            continue
        normalized = normalize_payload_name(member.name)
        if normalized in files:
            raise ValueError(f"duplicate normalized payload path: {normalized}")
        files[normalized] = member

    required = {
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiag.dylib",
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiag.plist",
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiagHelper.dylib",
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiagHelper.plist",
        "Library/LaunchDaemons/com.lns.pogr.aacpdiagd.plist",
        "usr/bin/aacpdiagd",
    }
    missing = sorted(required - set(files))
    if missing:
        raise ValueError(f"missing payload files: {missing}")

    expected_architectures = {
        (CPU_TYPE_ARM64, 0),
        (CPU_TYPE_ARM64, 2),
    }
    for dylib_name in (
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiag.dylib",
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiagHelper.dylib",
        "usr/bin/aacpdiagd",
    ):
        extracted = archive.extractfile(files[dylib_name])
        if extracted is None:
            raise ValueError(f"cannot read {dylib_name}")
        architectures = macho_architectures(extracted.read())
        if not expected_architectures.issubset(architectures):
            raise ValueError(
                f"{dylib_name} architectures {architectures} do not contain "
                f"{expected_architectures}"
            )

    if files["usr/bin/aacpdiagd"].mode & 0o111 == 0:
        raise ValueError("usr/bin/aacpdiagd is not executable")
    expected_plist_path = (
        pathlib.Path(__file__).resolve().parent.parent
        / "daemon"
        / "com.lns.pogr.aacpdiagd.plist"
    )
    if not expected_plist_path.is_file():
        raise ValueError(f"source daemon plist is missing: {expected_plist_path}")
    expected_plist = plistlib.loads(expected_plist_path.read_bytes())
    daemon_plist_name = "Library/LaunchDaemons/com.lns.pogr.aacpdiagd.plist"
    daemon_plist_extracted = archive.extractfile(files[daemon_plist_name])
    if daemon_plist_extracted is None:
        raise ValueError("cannot read packaged LaunchDaemon plist")
    daemon_plist_bytes = daemon_plist_extracted.read()
    daemon_plist = plistlib.loads(daemon_plist_bytes)
    if daemon_plist != expected_plist:
        raise ValueError(
            "packaged LaunchDaemon plist differs structurally from source"
        )

    if daemon_plist.get("Label") != "com.lns.pogr.aacpdiagd":
        raise ValueError("LaunchDaemon has an unexpected Label")
    if daemon_plist.get("ProgramArguments") != [
        "/var/jb/usr/bin/aacpdiagd"
    ]:
        raise ValueError("LaunchDaemon has an unexpected ProgramArguments")
    for key in ("RunAtLoad", "KeepAlive"):
        if daemon_plist.get(key) is not True:
            raise ValueError(f"LaunchDaemon {key} must be true")
    if daemon_plist.get("ThrottleInterval") != 2:
        raise ValueError("LaunchDaemon has an unexpected ThrottleInterval")
    if daemon_plist.get("ProcessType") != "Background":
        raise ValueError("LaunchDaemon has an unexpected ProcessType")
    if daemon_plist.get("StandardOutPath") != (
        "/var/tmp/com.lns.pogr.aacpdiag/daemon-stdout.log"
    ):
        raise ValueError("LaunchDaemon has an unexpected StandardOutPath")
    if daemon_plist.get("StandardErrorPath") != (
        "/var/tmp/com.lns.pogr.aacpdiag/daemon-stderr.log"
    ):
        raise ValueError("LaunchDaemon has an unexpected StandardErrorPath")

    ui_filter_name = (
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiag.plist"
    )
    helper_filter_name = (
        "Library/MobileSubstrate/DynamicLibraries/"
        "PodsGrantAACPDiagHelper.plist"
    )
    ui_extracted = archive.extractfile(files[ui_filter_name])
    helper_extracted = archive.extractfile(files[helper_filter_name])
    if ui_extracted is None or helper_extracted is None:
        raise ValueError("cannot read filter plists")
    ui_filter = plistlib.loads(ui_extracted.read())
    helper_filter = plistlib.loads(helper_extracted.read())
    if "com.apple.Preferences" not in (
        ui_filter.get("Filter", {}).get("Bundles", [])
    ):
        raise ValueError("UI filter is missing com.apple.Preferences")
    helper_executables = helper_filter.get("Filter", {}).get("Executables")
    if helper_executables != ["bluetoothd"]:
        raise ValueError(
            f"helper filter must target only bluetoothd: "
            f"{helper_executables!r}"
        )

    binary_markers = {
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiag.dylib": (
            b"source=aacp_ui",
            PACKAGE_VERSION.encode("ascii"),
        ),
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiagHelper.dylib": (
            b"source=helper",
            PACKAGE_VERSION.encode("ascii"),
        ),
        "usr/bin/aacpdiagd": (
            b"source=aacpdiagd",
            PACKAGE_VERSION.encode("ascii"),
        ),
    }
    runtime_markers = {
        "Library/MobileSubstrate/DynamicLibraries/PodsGrantAACPDiag.dylib": (
            DIAGNOSTIC_MARKER,
            b"Active FD Sent / Unconfirmed",
        ),
        "Library/MobileSubstrate/DynamicLibraries/"
        "PodsGrantAACPDiagHelper.dylib": (
            DIAGNOSTIC_MARKER,
            b"active_aacp_fd_tx_unconfirmed",
            b"active_aacp_fd_tx_failed",
        ),
    }
    for binary_name, markers in runtime_markers.items():
        extracted = archive.extractfile(files[binary_name])
        if extracted is None:
            raise ValueError(f"cannot read {binary_name}")
        data = extracted.read()
        missing_markers = [marker for marker in markers if marker not in data]
        if missing_markers:
            raise ValueError(
                f"{binary_name} is missing runtime markers: "
                f"{missing_markers}"
            )
    for binary_name, markers in binary_markers.items():
        extracted = archive.extractfile(files[binary_name])
        if extracted is None:
            raise ValueError(f"cannot read {binary_name}")
        data = extracted.read()
        missing_markers = [marker for marker in markers if marker not in data]
        if missing_markers:
            raise ValueError(
                f"{binary_name} is missing markers: {missing_markers}"
            )

    print(
        f"package={package} payload={payload_name} files={len(files)} "
        f"control={control_archive_name} scripts={','.join(sorted(scripts))} "
        f"architectures=arm64,arm64e package_version={control['Version']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
